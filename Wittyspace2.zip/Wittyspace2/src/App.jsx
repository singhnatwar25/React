import React from 'react'
import Header from './Header'
import Landing from './Landing'
import Shoping from './Shoping'
function App() {
  return (
    <div>
      <Header/>
      <Shoping/>
    </div>
  )
}

export default App